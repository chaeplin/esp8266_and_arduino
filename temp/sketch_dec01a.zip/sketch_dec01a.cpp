#line 1 "sketch_dec01a.ino"
#include "Arduino.h"
void setup();
void loop();
#line 1
void setup() {
                                           

}

void loop() {
                                                

}

